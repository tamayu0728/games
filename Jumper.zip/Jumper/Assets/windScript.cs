﻿using UnityEngine;
using System.Collections;

public class windScript : MonoBehaviour {
	public float maxDistance;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (this.transform.position.x < maxDistance) {
		
			Destroy (this.gameObject);

		}
	}
}
