﻿using UnityEngine;
using System.Collections;

public class Pause : SingletonMonoBehaviour<Pause> {
	
	public bool isProgress;
	public GameObject pauseLabel;

	// Use this for initialization
	void Start () {
		isProgress = false;
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	public void PauseButtonPushed (){
		Debug.Log("pause");
		
		Time.timeScale = (isProgress)?1:0; //0 is stop
		isProgress = !isProgress;
		
		if(isProgress){
			pauseLabel.SetActive(true);
			GameObject.Find("RetryButton").gameObject.SetActive(true);
			GameObject.Find("TitleButton").gameObject.SetActive(true);
		}else{
			pauseLabel.SetActive(false);
			GameObject.Find("RetryButton").gameObject.SetActive(false);
			GameObject.Find("TitleButton").gameObject.SetActive(false);
		}
		

		
	}
}
