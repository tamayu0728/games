﻿using UnityEngine;
using System.Collections;

public class ObjectRemover : MonoBehaviour {

	// 接触したオブジェクトを削除していく.
	void OnCollisionEnter2D (Collision2D coll) {
		// 足場があたったら削除する.
		if (coll.gameObject.tag == "ground") {
			GameObject.Destroy (coll.gameObject);
		}
	}
}
