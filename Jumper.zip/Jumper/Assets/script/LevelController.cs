﻿using UnityEngine;
using System.Collections.Generic;

// 次の足場を継ぎ足して足場とジャンピーを移動させる.
public class LevelController : SingletonMonoBehaviour<LevelController> {

	public float scrollSec=1f;	// 画面スクロールにかかる時間.
	private float t_scroll;	// 画面スクロールカウント用.
	
	public float jumpyScrollSec = 0.5f;	//  jumpy's scroll speed.
	private float t_jp_scroll;
	
	public GameObject housePrefab;	// 家のプレハブ.
	public GameObject stagePrefab;	// 足場のプレハブ.

	//public float stageDistance = 4f;	// 次の足場の出る距離.
	public float stagespownRDistance;	// 次の足場の出る範囲の画面右端からの距離.
	public float stagespownLDistance;	// 次の足場の出る範囲の画面中央からの距離.
	private GameObject player;			// プレイヤーの参照.
	private GameObject stageRoot;		// ステージオブジェクトのルート,高さと.
	
	private bool isJumpyCenter = true;

	// 画面内の足場のリスト(ジャンプ前は[0]が乗ってる足場)
	public List<GameObject> stageList{ get; private set; }
	// 足場のリストに対応する足場の高さ(ランク)
	public List<int> stageRank{ get; private set; }

	private Vector3 stage1Pos,stage2Pos;	// 初期の足場の位置.
	
	// 自動生成する足場の位置設定. 画面遷移後の位置を基準とする.
	//public float stage_xMin,stage_xMax,stage_yMin,stage_ylMax,stage_yrMax;
	// ステージの最小幅とそれに加えるランダム幅.
	//public float stage_sizeMin=1,stage_sizeNoise=1;
	// ステージの最小個数とランダム個数.
	public int stageMinRank, stageNoiseRank;

	private roadScrollerScript RoadScroller1;
	private roadScrollerScript RoadScroller2;

	// スクロール前の足場の画面左端からの位置.
	private float before_stageX;
	// スクロール後の足場の画面左端からの位置.
	public float def_stageX;
	private CameraController cam;
	private float old_x;
	// ジャンピーの足下から胴体(transform.position)までの距離.
	public float jumpyYDistance;

	void Start(){
		Init();
	}
	// 一番始めの初期化.
	void Init () {
		player = GameObject.FindGameObjectWithTag("Player");
		stageRoot = GameObject.Find("Stage Root");
		GameObject stage1 = GameObject.Find("Stage1");
		GameObject stage2 = GameObject.Find("Stage2");
		stageList = new List<GameObject>();
		stageRank = new List<int> ();
		stageList.Add(stage1);
		stageRank.Add (1);
		stageList.Add(stage2);
		stageRank.Add (1);
		t_scroll = 0f;

		// メインカメラの取得.
		cam = GameObject.FindGameObjectWithTag ("MainCamera").GetComponent<CameraController> ();
		
		stage1Pos = stage1.transform.position;
		stage2Pos = stage2.transform.position;

		RoadScroller1 = GameObject.Find ("BillScroller").GetComponent<roadScrollerScript>();
		RoadScroller2 = GameObject.Find ("BillScroller2").GetComponent<roadScrollerScript>();

	}
	// ReStart
	public void Restart(ref GameObject nextPlayer){
		// 今ある足場をすべて削除.
		foreach(GameObject st in stageList)
			GameObject.Destroy(st);
		stageList.Clear();
		stageRank.Clear ();
		GameObject stage1 = Instantiate(housePrefab) as GameObject;	// 初期状態の位置の足場を生成.
		stage1.transform.parent = stageRoot.transform;
		stage1.transform.position = stage1Pos;
		stageList.Add(stage1);
		stageRank.Add (1);
		GameObject stage2 = Instantiate(stagePrefab) as GameObject;
		stage2.transform.parent = stageRoot.transform;
		stage2.transform.position = stage2Pos;
		stage2.transform.FindChild("HouseOne").gameObject.SetActive(true);
		// コライダを適切な位置に移動.
		SetHouseColliderPos (ref stage2, 1);
		stageList.Add(stage2);
		stageRank.Add (1);
		// 再配置されたプレイヤーの参照を取得.
		player = nextPlayer;	// GameObject.FindGameObjectWithTag("Player");
	}
	
	// ジャンプ成功後次の足場を用意して移動させる.
	// スクロールしてから足場を出す用に変更.
	public void ScrollToNextStage(){
		// 次の足場を生成.
		/*
		GameObject nextStage = Instantiate(stage) as GameObject;
		nextStage.transform.parent = stageRoot.transform;
		nextStage.transform.position = GetNextStagePosition(player.transform.position);
		// ステージリストに次の足場を追加.
		stageList.Add(nextStage);
		*/

		// ジャンピーのy座標を補正.
		Vector3 adjustPos = player.transform.position;
		float spriteY = stageList [1].GetComponentInChildren<SpriteRenderer> ().bounds.size.y;
		adjustPos.y = stageRank [1] * spriteY+jumpyYDistance + cam.base_down;//
			//+cam.base_down;
		Debug.Log ("spriteY:"+spriteY+"stagerank:"+stageRank[1]+"adjusty:" + adjustPos.y);
		player.transform.position = adjustPos;

		//スクロール前の足場のx座標.
		before_stageX = stageList[1].transform.position.x - cam.base_left;
		Debug.Log ("befores_stage " + before_stageX);
		old_x = before_stageX;
		// スクロール処理.
		GameController.Instance.state = GameController.GameState.SCROLLING;
		RoadScroller1.ScrollStartFlag = true;
		RoadScroller2.ScrollStartFlag = true;
		// とりあえずスクロールしない.
		//EndScroll();
	}
	
	// スクロール後の処理.
	public void EndScroll () {
		// 画面外に出た足場を削除.
		GameObject.Destroy (stageList [0]);
		stageList.RemoveAt (0);
		stageRank.RemoveAt (0);
		// ステージリストに次の足場を追加.
		GameObject nextStage = Instantiate (stagePrefab) as GameObject;
		nextStage.transform.parent = stageRoot.transform;
		// カメラ中央から右端-stagespownRDistance
		nextStage.transform.position = new Vector3 (Random.Range (cam.transform.position.x+stagespownLDistance, cam.base_right-stagespownRDistance), cam.base_down, 0);//GetNextStagePosition ();
		// ステージの高さをランダムに指定. IntだとMaxの値が含まれないようなので+1
		int rank = Random.Range (stageMinRank, stageMinRank + stageNoiseRank+1);
		// ステージの幅をランダムに指定.
		//nextStage.transform.localScale = new Vector3(Random.value*stage_sizeNoise+stage_sizeMin,1,1);
		// ステージリストに次の足場を追加.
		stageList.Add (nextStage);
		stageRank.Add (rank);
		// 次の足場を表示する.
		nextStage.transform.FindChild (StageRanktoName(rank)).gameObject.SetActive (true);
		// 足場のあたり判定の位置を調整.
		SetHouseColliderPos (ref nextStage,rank);
		//float colY = nextStage.GetComponentInChildren<SpriteRenderer> ().bounds.size.y * rank + cam.base_down;
		//Debug.Log ("colY:" + colY);
		//nextStage.transform.FindChild ("HouseCollider").position = new Vector3 (nextStage.transform.position.x, colY, 0);
		// ジャンピーを建物原点にセット開始.
		isJumpyCenter = false;

		RoadScroller1.ScrollStartFlag = false;
		RoadScroller2.ScrollStartFlag = false;


		// プレイ再開.
		GameController.Instance.state = GameController.GameState.PLAYING;
		// ジャンピーの状態をレディにする.
		player.GetComponent<Jumpy> ().ToReady ();
	}
	
	/*
	// プレイヤーの位置から次の足場の位置を求める.
	Vector3 GetNextStagePosition(Vector3 playerPos){
		// yはジャンピーから-1.
		playerPos.y -= 1f;
		// xは任意の距離.
		playerPos.x += stageDistance;
		return playerPos;
	}
	*/
	/*
	// 画面の位置から次の足場の位置を求める.
	Vector3 GetNextStagePosition(){
		float posx = Random.Range(stage_xMin,stage_xMax);
		// x座標からyの最大値を求める.
		float yMax = stage_yrMax + (posx-stage_xMin) * ((stage_yrMax - stage_ylMax)/(stage_xMax-stage_xMin));
		float posy = Random.Range(stage_yMin,yMax);
		return new Vector3(posx,posy,0);
	}
	*/
	void Update () {
	
	if(!isJumpyCenter){
		//Debug.Log("center");
		Vector3 nextjumpy_pos = new Vector3(stageList[0].transform.position.x, player.transform.position.y, 0f);
		//Debug.Log (nextjumpy_pos);
		//Debug.Log (player.transform.position);
		t_jp_scroll += Time.deltaTime;
		//ジャンピーの足場中央への移動終了.
		if(t_jp_scroll>=jumpyScrollSec){
			t_jp_scroll = 0f;
			transform.position = nextjumpy_pos;
			isJumpyCenter = true;
		}else{// 中央へ向けた移動.
			float tRate = t_jp_scroll/jumpyScrollSec;
			//transform.position = Vector3.Lerp (player.transform.position, nextjumpy_pos, tRate);
			iTween.MoveTo(player, nextjumpy_pos, tRate);
			
		}
	}
	
		// スクロール処理.
		if (GameController.Instance.state == GameController.GameState.SCROLLING) {

			// Playerが初期位置に来るまで画面のオブジェクトを移動.
			t_scroll += Time.deltaTime;
			// スクロール終了
			if (t_scroll >= scrollSec) {
				t_scroll = 0f;
				EndScroll();
			} else {
				// スクロール処理.
				float tRate = t_scroll / scrollSec;
				/*
				//Vector3 nextStagePos = Vector3.Lerp ( stageList[1].transform.position,stage1Pos, tRate);
				//Vector3 nextPlayerPos = Vector3.Lerp (player.transform.position, GameController.Instance.defPlayerPos, tRate);
				Vector3 deltaPos = nextPlayerPos - player.transform.position;	// nextPlayerPos.
				player.transform.position += deltaPos;
				foreach (GameObject stage in stageList) {
					stage.transform.position += deltaPos;
				}
				*/
				// 画面左からの座標を
			
				float nextX = Mathf.Lerp (before_stageX, def_stageX, tRate);
				//Debug.Log ("nextX : " + nextX + " [1]pos.x : " + stageList [1].transform.position.x);
				float deltaX = nextX - old_x;
				old_x = nextX;
				player.transform.position = AddPositionX (deltaX, player.transform.position);
				foreach (GameObject stage in stageList) {
					stage.transform.position = AddPositionX (deltaX, stage.transform.position);
				}
				/*
				float deltaX = nextX - (stageList [1].transform.position.x + cam.base_left);

				player.transform.position = AddPositionX (deltaX, player.transform.position);
				foreach (GameObject stage in stageList) {
					stage.transform.position = AddPositionX (deltaX, stage.transform.position);
				}
				*/
			}

			
		}
	}

	public Vector3 AddPositionX(float x,Vector3 pos){
		Vector3 p = pos;
		p.x += x;
		pos = p;
		return pos;
	}

	public string StageRanktoName(int rank){
		switch (rank) {
		case 0:
			return null;
			break;
		case 1:
			return "HouseOne";
			break;
		case 2:
			return "HouseTwo";
			break;
		case 3:
			return "HouseThree";
			break;
		case 4:
			return "HouseFour";
			break;
		case 5:
			return "HouseFive";
			break;
		}
		return null;
	}

	void SetHouseColliderPos(ref GameObject house,int rank){
		float colY = house.GetComponentInChildren<SpriteRenderer> ().bounds.size.y * rank + cam.base_down;
		if (rank >= 3)
			colY -= (rank-2)*0.5f;
		Debug.Log ("colY:" + colY);
		house.transform.FindChild ("HouseCollider").position = new Vector3 (house.transform.position.x, colY, 0);
	}
}
