﻿using UnityEngine;
using System.Collections;

// ゲーム全体のトランジションを制御.
// カメラのスクロールも管理する.
public class GameController : SingletonMonoBehaviour<GameController> {

	private bool isTransision = false;
	public float transisionSec = 1.5f;	// タイトルからの遷移にかかる時間.
	private float t_count=0f;

	public Vector3 camera_title_Pos;
	public float camera_title_Size;
	public Vector3 camera_Play_Pos;
	public float camera_Play_Size;
		
	public GameObject tutorialImage;
	public GameObject logoImage;
	public GameObject scoreLabel;
	public GameObject bestScoreLabel;
	public GameObject comboLabel;
	public GameObject resultScoreLabel;
	public GameObject background;
	public GameObject honorLabel;
	
	public GameObject titleButton;
	public GameObject retryButton;
	public GameObject pauseButton;
	
	public Camera backCamera;
	public CameraController mainCam;
	
	private GameObject player;	// プレイヤーの参照.
	public GameObject playerPrefab;	// プレイヤーのプレハブ.
	public Vector3 defPlayerPos{ get; private set;}	// プレイヤーの初期位置.
	public Vector3 defPlayerScale{ get; private set;}	// 初期サイズ.
	
	public int score; // 真ん中着地ボーナス
	public int comboCount = 0;
	
	public GameObject greatImage;

	public GameObject goodImage;

	// Game Statement
	public enum GameState {
		TITLE,		// タイトル画面.
		TUTORIAL,	// チュートリアル表示中.
		PLAYING,	// プレイ中.
		SCROLLING,	// 次の足場が出てくるまでのスクロール中.
		RESULT,		// 結果表示中.
	}
	public GameState state;
	
	// 変数宣言
	public int frameRate;

	// Frame rate
	void Awake () {
		Application.targetFrameRate = frameRate;
		if (mainCam == null) {
			mainCam = GameObject.Find ("Main Camera").GetComponent<CameraController> ();
		}
		if (backCamera == null) {
			backCamera = GameObject.Find ("BackGround Camera").GetComponent<Camera> ();
		}
	}

	// Use this for initialization
	void Start () {

//		AudioManager.Instance.FadeGameBGM ();
		// Debug
		state = GameState.TITLE;
		mainCam.transform.position = camera_title_Pos;
		mainCam.mainCam.orthographicSize = camera_title_Size;
		backCamera.transform.position = camera_title_Pos;
		backCamera.orthographicSize = camera_title_Size;
		
		// UI
		tutorialImage = GameObject.Find ("tutorial").gameObject;
		tutorialImage.SetActive(false);
		logoImage = GameObject.Find ("logo").gameObject;
		logoImage.SetActive(true);
		titleButton = GameObject.Find ("TitleButton").gameObject;
		titleButton.SetActive(false);
		retryButton = GameObject.Find ("RetryButton").gameObject;
		retryButton.SetActive(false);
		pauseButton = GameObject.Find ("PauseButton").gameObject;
		pauseButton.SetActive(false);
		greatImage = GameObject.Find ("greatImage").gameObject;
		greatImage.SetActive(false);
		goodImage = GameObject.Find ("goodImage").gameObject;
		goodImage.SetActive(false);
		background = GameObject.Find ("Background").gameObject;
		background.SetActive(false);
		scoreLabel = GameObject.Find("ScoreLabel").gameObject;
		scoreLabel.SetActive(false);
		comboLabel = GameObject.Find("ComboLabel").gameObject;
		comboLabel.SetActive(false);
		bestScoreLabel = GameObject.Find ("BestLabel").gameObject;
		bestScoreLabel.SetActive (false);
		resultScoreLabel = GameObject.Find("ResultScoreLabel").gameObject;
		resultScoreLabel.SetActive(false);
		honorLabel = GameObject.Find("HonorLabel").gameObject;
		honorLabel.SetActive(false);
		
		// プレイヤーの参照の取得,初期位置とサイズの保存.
		player = GameObject.FindGameObjectWithTag("Player");
		defPlayerPos = player.transform.position;
		defPlayerScale = player.transform.localScale; 

		PlayerPrefs.SetInt ("best",0);
		
	}
	
	// Update is called once per frame
	void Update () {
		//ゲームをスタートステイトへ
		if (Input.GetMouseButtonDown (0) && state == GameState.TITLE && !isTransision) {
			isTransision = true;
			t_count = 0f;
		}
		if (state == GameState.TITLE && isTransision) {
			logoImage.SetActive(false);
			// カメラの遷移が終わったらチュートリアル状態に.
			if (t_count >= transisionSec) {
				t_count = 0f;
				ToTutorial ();
				isTransision = false;
				// カメラの左下を固定してスケールをかえられるようにする.
				mainCam.StartKeep_leftdown ();
			} else {
				// カメラを滑らかに移動させる.
				t_count += Time.deltaTime;
				float tRate = t_count / transisionSec;
				mainCam.transform.position = Vector3.Lerp (camera_title_Pos, camera_Play_Pos, tRate);
				mainCam.mainCam.orthographicSize = Mathf.Lerp (camera_title_Size, camera_Play_Size, tRate);
				backCamera.transform.position = Vector3.Lerp (camera_title_Pos, camera_Play_Pos, tRate);
				backCamera.orthographicSize = Mathf.Lerp (camera_title_Size, camera_Play_Size, tRate);
			}
		}
		if (Input.GetMouseButtonUp (0) && state == GameState.TUTORIAL) {
			// チュートリアルでポップアップをタッチしたらプレイ状態に.
			ToPlaying ();
		}
		// ゲーム中.
		if (state == GameState.PLAYING) {

		}
		
		scoreLabel.GetComponent<UILabel>().text = "知名度: " + score.ToString();
	}
	// To Tutorial
	void ToTutorial (){
		state = GameState.TUTORIAL;
		tutorialImage.SetActive(true);
		
	}
	// To Playing
	void ToPlaying() {

		state = GameState.PLAYING;

		tutorialImage.SetActive(false);
		pauseButton.SetActive(true);
		scoreLabel.SetActive(true);
		if (score > PlayerPrefs.GetInt ("best")) {
			PlayerPrefs.SetInt("best",score);
			bestScoreLabel.SetActive(true);
		}

	}
	
	// To Result
	public void ToResult() {			
		string honor ="";
		
		background.SetActive(true);
		
		resultScoreLabel.GetComponent<UILabel>().text = "知名度: " + score.ToString();
		resultScoreLabel.SetActive(true);
		
		if(score < 200) { honor = "ただの素人"; }
		else if(score < 500){ honor = "駆け出しスタントマン"; }
		else if(score < 1000){ honor = "売れっ子スタントマン"; }
		else if(score < 2000){ honor = "ハリウッドスター"; }
		else { honor="燃えよドラゴン"; }
	
		honorLabel.GetComponent<UILabel>().text = honor;
		honorLabel.SetActive(true);
		
		retryButton.SetActive(true);
		titleButton.SetActive(true);
		
		pauseButton.SetActive(false);
		scoreLabel.SetActive(false);
		bestScoreLabel.SetActive (false);
		
		// リザルトを生成
		state = GameState.RESULT;

	}
	
	// Restart
	public void Restart() {
		// ステージ・キャラのリセット.
		Reset();
		// 新しいゲーム開始.
		state = GameState.PLAYING;
		
	}
	
	// To Title
	public void ToTitle() {
	
		logoImage.SetActive(true);
	
		Reset();
		// カメラの位置とサイズを元に戻す.
		mainCam.transform.position = camera_title_Pos;
		mainCam.mainCam.orthographicSize = camera_title_Size;
		backCamera.transform.position = camera_title_Pos;
		backCamera.orthographicSize = camera_title_Size;

		mainCam.Reset ();

		state = GameState.TITLE;
		
		scoreLabel.SetActive(false);
		pauseButton.SetActive(false);

	}
	
	void Reset(){
		
		pauseButton.SetActive(true);
		scoreLabel.SetActive(true);
		
		// スコア削除
		resultScoreLabel.SetActive(false);
		honorLabel.SetActive(false);
		background.SetActive(false);

		// ゲームステージの進行状態をリセット.
		GameStageController.Instance.Reset ();

		// カメラの位置とサイズを元に戻す.
		mainCam.transform.position = camera_Play_Pos;
		mainCam.mainCam.orthographicSize = camera_Play_Size;
		backCamera.transform.position = camera_Play_Pos;
		backCamera.orthographicSize = camera_Play_Size;

		score = 0;
		comboCount = 0;
		comboLabel.SetActive(false);
		
		
		// 今いるプレイヤーを破棄.
		GameObject.Destroy( GameObject.FindGameObjectWithTag("Player"));
		// 新しいプレイヤーを配置.
		GameObject newPlayer = Instantiate( playerPrefab) as GameObject;
		newPlayer.transform.parent = GameObject.Find("GameScreen").transform;
		newPlayer.transform.position = defPlayerPos;
		newPlayer.transform.localScale = defPlayerScale;
		// ジャンピーの初期化を呼ぶ.
		newPlayer.SetActive (true);
		newPlayer.GetComponent<Jumpy>().Start();
		//newPlayer.transform.FindChild("hang_glider").gameObject.SetActive(false);
		// 新しいプレイヤーの参照を取得.
		player = newPlayer;
		// ステージの状態を元に戻す.
		LevelController.Instance.Restart(ref newPlayer);
	}
}
