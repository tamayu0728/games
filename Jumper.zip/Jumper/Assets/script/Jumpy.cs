using UnityEngine;
using System.Collections;

public class Jumpy : MonoBehaviour {

	bool isReady;

	enum State{
			READY,
			RISING,
			FALLING,
			WAITING,
	}
	private State state;

	private AudioSource sound01;
	private AudioSource sound02;
	public float t_flying=0;
	public float deltaAngle = 15f;
	public int gliderForceX = 10;
	public int gliderForceY = 10;
	public int firstImplus = 10;
	public int minusInplus = 0;
	public int impulseForce = 10;
	public float attenuator = 5; 
	public GameObject glider;
	public GameObject player;
	public GameObject EndFly;
	public GameObject GreatEnd;
	public int addForce = 3;
	public GameObject OneWind;
	private GameObject windPrefab;
	private int count = 0;
	public int vx = 0;
	public int vy = 0;
	
	public bool isBeforeGreat = false;
	public Animator GameOverAnimator;
	
	private float targetSwingUpAngle = 0f;
	public float swingUpSpeed = 90f;
	public float swingDownSpeed = 30f;	

	public CameraController mainCam;
	public float cameraFollowUpperDistance = 0f;	// スクロールし始める画面上端からの距離.
	public float temp_cameraY;

	// Use this for initialization
	public void Start () {
		state = State.READY;
		glider.SetActive(false);
		EndFly.SetActive (false);
		GreatEnd.SetActive (false);

		mainCam = GameObject.Find ("Main Camera").GetComponent<CameraController> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (GameController.Instance.state != GameController.GameState.PLAYING)
			return;
		else
		// 足場に乗って待機中
		if (Input.GetMouseButtonDown (0) && state == State.READY) {
			// ジャンプ開始
			t_flying = 0;
			count = 0;
			LevelController.Instance.stageList[0].transform.GetComponentInChildren<BoxCollider2D>().enabled = false;
			state = State.RISING;
		}
		if (Input.GetMouseButtonUp (0) && state == State.RISING) {
			// 落下開始
			this.GetComponent<Rigidbody2D>().AddForce(Vector3.down * firstImplus,ForceMode2D.Impulse);
			ToFalling();
		}
		switch (state) {
			case State.RISING:
				Animator playerAnimator = this.transform.FindChild ("body").gameObject.GetComponent<Animator> ();
				playerAnimator.Play ("BalloonUp");
				this.GetComponent<Rigidbody2D>().AddForce (Vector3.up * addForce);

				break;


//			case State.FALLING:
//				player.SetActive (false);
//				glider.SetActive (true);
//				EndFly.SetActive(false);
//				GreatEnd.SetActive(false);
//
//				t_flying += Time.deltaTime;
//				Vector3 eulerAngle = this.transform.localEulerAngles;//.eulerAngles;
//
//				this.rigidbody2D.AddForce (Vector3.down * gliderForceY);
//				if(t_flying * attenuator < 15f){ 
//				this.rigidbody2D.AddForce (Vector3.up * t_flying * attenuator);
//				}else{
//				this.rigidbody2D.AddForce (Vector3.up *  15f);
//				}
//				this.rigidbody2D.AddForce (Vector3.right * gliderForceX);
//				if (Input.GetMouseButtonDown (0)) {
//					windPrefab = (GameObject)Instantiate(OneWind);
//					if (eulerAngle.z < 140f) {
//						targetSwingUpAngle = eulerAngle.z + deltaAngle;
//						this.rigidbody2D.AddForce (Vector3.up * (impulseForce - minusInplus * count), ForceMode2D.Impulse);
//						count++;
//					}else{
//						//Animator GameOverAnimator = this.transform.FindChild ("hang_glider").gameObject.GetComponent<Animator> ();
//						GameOverAnimator.Play("GameOver");
//						LevelController.Instance.stageList[1].transform.GetComponentInChildren<BoxCollider2D>().enabled = false;
//					}
//				}
//				Debug.Log(eulerAngle.z);
//
//				if (eulerAngle.z <= targetSwingUpAngle) {
//					eulerAngle.z += swingUpSpeed * Time.deltaTime;
//				} else {
//					targetSwingUpAngle = 0f;
//					if (eulerAngle.z >= 60f && eulerAngle.z <= 180) {
//						eulerAngle.z -= swingDownSpeed * Time.deltaTime;
//					} else {
//						count = 0;
//						eulerAngle.z = 60f;
//					}
//				}	
//			transform.localEulerAngles = eulerAngle;
//				break;
//
//			case State.WAITING:
//
//				break;

		case State.FALLING:
			player.SetActive (false);
			glider.SetActive (true);
			EndFly.SetActive(false);
			GreatEnd.SetActive(false);

			t_flying += Time.deltaTime;
			Vector3 eulerAngle = this.transform.localEulerAngles;//.eulerAngles;
			this.GetComponent<Rigidbody2D>().velocity = new Vector2(vx,Mathf.Min(-5.0f,vy + t_flying * 10f));
			if (Input.GetMouseButtonDown (0)) {
				windPrefab = (GameObject)Instantiate(OneWind);
				if (eulerAngle.z < 140f) {
					targetSwingUpAngle = eulerAngle.z + deltaAngle;
					this.GetComponent<Rigidbody2D>().AddForce (Vector3.up * impulseForce, ForceMode2D.Impulse);
					count++;
				}else{
					//Animator GameOverAnimator = this.transform.FindChild ("hang_glider").gameObject.GetComponent<Animator> ();
					GameOverAnimator.Play("GameOver");
					LevelController.Instance.stageList[1].transform.GetComponentInChildren<BoxCollider2D>().enabled = false;
				}
			}
			if (eulerAngle.z <= targetSwingUpAngle) {
				eulerAngle.z += swingUpSpeed * Time.deltaTime;
			} else {
				targetSwingUpAngle = 0f;
				if (eulerAngle.z >= 60f && eulerAngle.z <= 180) {
					eulerAngle.z -= swingDownSpeed * Time.deltaTime;
				} else {
					eulerAngle.z = 60f;
				}
			}    
			transform.localEulerAngles = eulerAngle;
			break;

		}

		if (state == State.RISING || state == State.FALLING) {
			// 画面の上端からある程度の距離にいるときに追従.
			if(this.transform.position.y >= mainCam.base_up-cameraFollowUpperDistance){

				Vector3 pos = mainCam.transform.position;
				pos.y = this.transform.position.y + cameraFollowUpperDistance - mainCam.mainCam.orthographicSize;
				mainCam.transform.position = pos;
			} else {
				// 下にいる場合追従しない.
				Vector3 p = mainCam.transform.position;
				p.y = temp_cameraY;
				mainCam.mainCam.transform.position = p;
				//mainCam.StartKeep_leftdown ();
			}
		}
	}

	void OnCollisionEnter2D(Collision2D coll) 
	{
		float diff_Stage_and_Player = 0f; // Greatとかの判定

		if (coll.gameObject.tag == "ground") {
			this.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
			this.GetComponent<Rigidbody2D>().angularVelocity = 0;
			this.GetComponent<Rigidbody2D>().Sleep();
			targetSwingUpAngle = 0f;
			state = State.READY;

			Vector3 pos = this.gameObject.transform.position;
			pos.y = coll.gameObject.transform.position.y + 2;
			this.gameObject.transform.position = pos;
			this.gameObject.transform.eulerAngles = new Vector3(0, 0, 0);
			// 次の目標の足場(stageList[1]に入っている足場)に接触したとき成功.
			if (coll.gameObject.transform.parent.gameObject == LevelController.Instance.stageList [1]) {

				//Debug.Log("touch");
				// 画面を遷移する.
				//LevelController.Instance.ScrollToNextStage ();
				//state = State.WAITING;	// 遷移が終わるまで待つ.
				
				// プレイヤー座標 と 目標点の中心の差分 からGreatとかの判定をする
				Debug.Log("Player.x : " + transform.position.x*10);
				Debug.Log("Coll.x: " + coll.gameObject.transform.position.x*10);
				
				diff_Stage_and_Player = Mathf.Abs(transform.position.x
					- coll.gameObject.transform.position.x);
				// とりあえず足場の長さが固定なのでマジックナンバーになってる
				// ステージが出来上がったときに要修正

				AudioSource[] audioSources = this.transform.GetComponents<AudioSource>();
				sound01 = audioSources[0];
				sound02 = audioSources[1];
				
				if(diff_Stage_and_Player < 0.6){
					GameController.Instance.greatImage.SetActive(true);
					sound02.PlayOneShot(sound02.clip);
					Invoke("setFalseToImages", 1);
					GameController.Instance.score += 100;
					if(PlayerPrefs.GetInt("best") < GameController.Instance.score){
						PlayerPrefs.SetInt("best",GameController.Instance.score);
						GameController.Instance.bestScoreLabel.SetActive(true);
					}
					glider.SetActive(false);
					EndFly.SetActive (false);
					GreatEnd.SetActive(true);
					
					if(isBeforeGreat){
						GameController.Instance.comboCount++;
						GameController.Instance.score += GameController.Instance.comboCount * 50;
						
						GameController.Instance.comboLabel.GetComponent<UILabel>().text = GameController.Instance.comboCount.ToString() + " COMBO!";
						GameController.Instance.comboLabel.SetActive(true);
						Debug.Log("comboCount : " + GameController.Instance.comboCount);
					}
					isBeforeGreat = true;
				}else{
					sound01.PlayOneShot(sound01.clip);
					GameController.Instance.goodImage.SetActive(true);
					Invoke("setFalseToImages", 1);
					GameController.Instance.score += 50;
					if(PlayerPrefs.GetInt("best") < GameController.Instance.score){
						PlayerPrefs.SetInt("best",GameController.Instance.score);
						GameController.Instance.bestScoreLabel.SetActive(true);
					}
					glider.SetActive(false);
					EndFly.SetActive (true);
					GreatEnd.SetActive(false);
					
					GameController.Instance.comboCount = 0;
					isBeforeGreat = false;
					GameController.Instance.comboLabel.SetActive(false);
				}
				//if(diff_Stage_and_Player < )
				// グライダーを非表示にしてボディを表示する.

				// ゲームのパラメータを次のステージのものにする.
				GameStageController.Instance.GotoNextGameStage ();
				
				state = State.WAITING;	 // 画面遷移が終わるまで待機させる.
				LevelController.Instance.ScrollToNextStage ();	
				
			}
			
		}
	}
	
	public void ToReady(){
		state = State.READY;
		Invoke ("ActiveStandPlayer", 0.5f);
		t_flying = 0;
		count = 0;

		temp_cameraY = mainCam.transform.position.y;
	}

	public void ToFalling(){
		state = State.FALLING;
	}
	
	void ActiveStandPlayer(){
		player.SetActive(true);
		EndFly.SetActive (false);
		GreatEnd.SetActive(false);
	}
	
	void setFalseToImages(){
		GameController.Instance.greatImage.SetActive(false);
		GameController.Instance.goodImage.SetActive(false);
		GameController.Instance.comboLabel.SetActive(false);
	}
}
