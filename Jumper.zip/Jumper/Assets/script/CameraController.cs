﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

	public Camera mainCam;
	public float base_left, base_down;
	private float def_orthSize;	// 初期画面サイズ.
	private float old_orthSize;

	public bool keep_leftdown;

	public float sizeTransitionSpeed;	// 画面の引く速度.
	private float t_Transition;	// 遷移カウント.
	private float before_Size;
	private float target_Size;
	private bool isTransition;

	// カメラ位置に追従させたいあたり判定領域と画面端からの距離.
	public GameObject rDeadArea, dDeadArea, uChangeArea;
	public float r_dist=1f, d_dist=-1f, u_dist=0.5f;

	public float base_right {
		get{ return base_left + 2f * mainCam.orthographicSize * mainCam.aspect; }
	}
	public float base_up {
		get{ return base_down + 2f * mainCam.orthographicSize; }
	}

	// Use this for initialization
	public void Start () {
		Init ();
		// 始めは追従しない.
		keep_leftdown = false;
		isTransition = false;
	}

	public void Reset(){
		Start ();
	}

	// 初期化. 追従の解除.
	void Init(){
		mainCam = this.gameObject.GetComponent<Camera> ();
		def_orthSize = mainCam.orthographicSize;
		old_orthSize = def_orthSize;
		base_left = -def_orthSize * mainCam.aspect; // 左端の座標
		base_down = -def_orthSize; // 下端の座標.
		Debug.Log (base_left + "" + base_down);
		AreaPositionAdjust ();
	}

	public void StartKeep_leftdown(){
		Init ();
		keep_leftdown = true;
	}
	
	// Update is called once per frame
	void Update () {
		if (isTransition) {
			t_Transition += Time.deltaTime;
			if (t_Transition >= sizeTransitionSpeed) {
				t_Transition = 0f;
				isTransition = false;
				mainCam.orthographicSize = target_Size;
			} else {
				float tRate = t_Transition / sizeTransitionSpeed;
				mainCam.orthographicSize = Mathf.Lerp (before_Size, target_Size, tRate);
			}
		}
		if (keep_leftdown && mainCam.orthographicSize != old_orthSize) {
			SetScreenByLeftDown ();
			old_orthSize = mainCam.orthographicSize;
		}
	}

	// 画面サイズトランジション開始.
	public void StartOrthographicSizeTransition(float targetSize){
		if (targetSize == mainCam.orthographicSize)
			return;
		before_Size = mainCam.orthographicSize;
		t_Transition = 0f;
		target_Size = targetSize;
		isTransition = true;
	}

	// 画面の左下の位置がずれないようにスケールを広げる.
	// ついでに画面端の座標も更新.
	// ついでに画面の周りに置くパーツの位置も調整.
	void SetScreenByLeftDown(){
		float deltaH = mainCam.orthographicSize - def_orthSize;
		Vector3 pos = transform.position;
		pos.y = deltaH;
		pos.x = deltaH * mainCam.aspect;
		transform.position = pos;
		base_left = -mainCam.orthographicSize * mainCam.aspect + pos.x;
		base_down = -mainCam.orthographicSize + pos.y;

		AreaPositionAdjust ();
	}

	void AreaPositionAdjust(){
		Vector3 p = rDeadArea.transform.position;
		p.x = base_right + r_dist;
		p.y = transform.position.y;
		rDeadArea.transform.position = p;
		p = dDeadArea.transform.position;
		p.x = transform.position.x;
		p.y = base_down + d_dist;
		dDeadArea.transform.position = p;
		p = uChangeArea.transform.position;
		p.x = transform.position.x;
		p.y = base_up + u_dist;
		uChangeArea.transform.position = p;
	}

	/*
	void OnDrawGizmos(){
		Gizmos.color = new Color(1, 0, 0, 0.5F);
		Gizmos.DrawCube(new Vector3(base_left,base_down,0), new Vector3(1, 1, 1));
	}*/
}
