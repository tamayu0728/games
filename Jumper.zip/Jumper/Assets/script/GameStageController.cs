﻿using UnityEngine;
using System.Collections.Generic;

public class GameStageController  : SingletonMonoBehaviour<GameStageController> {

	public CameraController mainCamera;	// メインカメラ.
	private int gameStageCount; // クリアしたステージ数.
	private float oldOrthSize;
	[System.Serializable]
	public struct GameStage
	{
		public int stageMinRank;
		public int stageNoiseRank;
		public float stagespownRDistance;
		public float stagespownLDistance;
		public float OrthographicSize;
		public GameStage (int minR,int NoiseR, float  spownR,float spownL,float size){
			this.stageMinRank = minR;
			this.stageNoiseRank = NoiseR;
			this.stagespownRDistance =spownR;
			this.stagespownLDistance = spownL;
			this.OrthographicSize = size;
		}
	}

	public List<GameStage> StageParamList = new List<GameStage>();

	// ステージの進行状態をリセット.
	public void Reset(){
		gameStageCount = 0;
	}

	// １ステージ進む.
	// ステージパラメーターを更新する.
	public void GotoNextGameStage(){
		if (gameStageCount >= StageParamList.Count)
			SetStageParameter (StageParamList [StageParamList.Count - 1]);
		else
			SetStageParameter (StageParamList [gameStageCount]);
		gameStageCount++;
	}

	void SetStageParameter ( GameStage stage){
		LevelController.Instance.stageMinRank = stage.stageMinRank;
		LevelController.Instance.stageNoiseRank = stage.stageNoiseRank;
		LevelController.Instance.stagespownRDistance = stage.stagespownRDistance;
		LevelController.Instance.stagespownLDistance = stage.stagespownLDistance;
		mainCamera.StartOrthographicSizeTransition (stage.OrthographicSize);
	}
	//public struct Gamestage
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
