using UnityEngine;
using System;
using System.Collections;

public class scrollRoad : MonoBehaviour {
	

	public float speedBairitsu = 1f;

	[SerializeField]
	float m_scrollSpeed = 5f;

	private bool m_isPause = false;

	[SerializeField]
	int m_spriteCount = 3;

	[SerializeField]
	float m_endPosition;

	[SerializeField]
	float m_returnPosition;

	private Transform m_Transform;


	public bool IsPause {
		
		set{ m_isPause = value;}
	}
	

	// Use this for initialization
	void Start () {

		m_Transform = transform;

	}
	
	// Update is called once per frame
	void Update () {

		if(m_isPause){

			m_Transform.position += Vector3.left * m_scrollSpeed * Time.deltaTime * speedBairitsu;

		}
	
	}
}
