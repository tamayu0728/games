﻿using UnityEngine;
using System.Collections;

public class Result : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	public void RetryButtonPushed (){
		GameController.Instance.Restart();
		
		GameObject.Find("RetryButton").SetActive(false);
		GameObject.Find("TitleButton").SetActive(false);
	}
	
	public void TitleButtonPushed (){
		GameController.Instance.ToTitle();
		
		GameObject.Find("RetryButton").SetActive(false);
		GameObject.Find("TitleButton").SetActive(false);
		GameObject.Find("scoreLabel").SetActive(false);
		GameObject.Find("PauseButton").SetActive(false);
	}
}
