﻿using UnityEngine;
using System.Collections;

public class roadScrollerScript : MonoBehaviour {

	[SerializeField]
	private GameObject[] m_RoadObjects;
	[SerializeField]
	private float m_RoadWidth;

	public Vector3 m_EndPoint;

	[SerializeField]
	private bool isCloud;

	[SerializeField]
	private float CloudHight;

	private bool scrollStartFlag = false;

	[SerializeField]
	private bool notMove;

	public GameObject[] Roads{
	
		get{ return m_RoadObjects;}
	}

	public bool ScrollStartFlag
	{
		set
		{
			scrollStartFlag = value;
		
		}
	}

	void Start(){
		if (!notMove) {
			scrollStartFlag = true;
		}
	
	}


	// Update is called once per frame
	void Update () {
//		if (isCloud) {
//	//		var cameraHight = transform.parent.GetComponent<CameraController> ().ScreenHight;
//			this.transform.position = new Vector3 (this.transform.position.x, -cameraHight + CloudHight , 0f);
//		}else{
//	//		var cameraHight = transform.parent.GetComponent<CameraController> ().ScreenHight;
//			this.transform.position = new Vector3 (this.transform.position.x, -cameraHight, 0f);
//		}
//
//
//	
	
		for (int i = 0; i < m_RoadObjects.Length; i++) {
			if(scrollStartFlag){
				m_RoadObjects[i].GetComponent<scrollRoad>().IsPause = true;
			}else{
			
				m_RoadObjects[i].GetComponent<scrollRoad>().IsPause = false;
			}

			if(m_RoadObjects[i].transform.position.x < m_EndPoint.x){
				var returnPos = ((i - 1) + m_RoadObjects.Length) % m_RoadObjects.Length;
				
				var returnPosition = m_RoadObjects[returnPos].transform.position.x + m_RoadWidth;
				
				Vector3 roadPosition = m_RoadObjects[i].transform.position;
				roadPosition.x = returnPosition;
				
				m_RoadObjects[i].transform.position = roadPosition;
			}
		}

	}
}
