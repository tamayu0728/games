﻿using UnityEngine;
using System.Collections;

public class DeadArea : MonoBehaviour {

	private AudioSource deadsound;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnCollisionEnter2D (Collision2D coll) {

		Debug.Log (coll.gameObject.name);
		if (coll.gameObject.tag == "Player") {
			AudioSource[] audioSources = this.transform.GetComponents<AudioSource>();
			deadsound = audioSources[0];
			
			deadsound.PlayOneShot(deadsound.clip);
			
			GameObject.Destroy(coll.gameObject);
			// やられ演出？.
			GameObject.Destroy(coll.gameObject);
			// とりあえず状態をリセット.
			GameController.Instance.ToResult();
			//GameController.Instance.Restart();
		}
	}

	void OnTriggerEnter2D(Collider2D coll){
		Debug.Log (coll.gameObject.name);
		if (coll.gameObject.tag == "Player") {
			AudioSource[] audioSources = this.transform.GetComponents<AudioSource>();
			deadsound = audioSources[0];
			
			deadsound.PlayOneShot(deadsound.clip);
			
			GameObject.Destroy(coll.gameObject);
			// やられ演出？.
			GameObject.Destroy(coll.gameObject);
			// とりあえず状態をリセット.
			GameController.Instance.ToResult();
			//GameController.Instance.Restart();
		}
	}
}
