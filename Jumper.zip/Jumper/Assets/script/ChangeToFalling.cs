﻿using UnityEngine;
using System.Collections;

public class ChangeToFalling : MonoBehaviour {

	void OnTriggerEnter2D (Collider2D coll) {
		Debug.Log ("coll"+coll.gameObject.name);
		if (coll.gameObject.tag == "Player") {
			// プレイヤーがあたったらFallingにする.
			coll.gameObject.GetComponent<Jumpy> ().ToFalling ();
		}
	}
}
