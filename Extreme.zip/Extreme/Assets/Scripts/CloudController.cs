﻿// Cloud.cs
// 雲の動きを制御する

using UnityEngine;
using System.Collections;

public class CloudController : MonoBehaviour {

	// 定数宣言
	private const int MAX_CLOUD = 300;
	private const float ADD_POS = 1.0f;

	// 開始処理
	void Start () {
		// 雲表示
		for(int i = 0; i < MAX_CLOUD; i ++) {
			GameObject cloud = Instantiate (Resources.Load("Prefabs/Cloud"), transform.position, Quaternion.identity) as GameObject;
			cloud.transform.position += new Vector3(i * 15.0f, 2.0f + (i % 2) * 2.0f - Random.Range (-1.0f, 1.0f), 0);
			cloud.transform.parent = transform;
		}
	}
	
	// 更新処理 
	void Update () {
		transform.position += new Vector3(ADD_POS * Time.deltaTime, 0, 0);
	}
}
