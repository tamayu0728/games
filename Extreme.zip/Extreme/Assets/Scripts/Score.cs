﻿using UnityEngine;
using System.Collections;

public class Score : MonoBehaviour {

	private Transform playerTrans;
	//飛距離
	private int score;
	//一桁プレハブ
	public	GameObject number;
	public  GameObject metor;
	public  GameObject metor2;
	//表示の配列
	private GameObject[] displays = new GameObject[6];
	//桁数
	private int digits;
	//表示の初期位置
	//private Vector3 offs = Vector3(5,5,0);
	private int maxScore = 0;
	private int best;
	//
	private bool isMetorUpdated;

	private GameObject bestLabelIns;

	void InitScore() {
		this.score = 0;
		this.digits = 0;

		//スコア保持
		this.best = (PlayerPrefs.HasKey("best"))?PlayerPrefs.GetInt("best"):0;
		this.isMetorUpdated=false;
	}

	public void UpdateScore(int score) {
		this.score = score;
	}

	//一桁増えるとプレハブ作る
	void UpdateDigits(){
		this.displays [this.digits] = Instantiate(number, transform.position + new Vector3(-0.75f + -0.55f*(this.digits), 0.1f,0), Quaternion.identity) as GameObject;
		if(best<score){
			this.displays [this.digits].GetComponent<Distance>().UpdateHighNum(0);
		}else{
			this.displays [this.digits].GetComponent<Distance>().UpdateNum(0);
		}
		this.displays [this.digits].transform.parent = gameObject.transform;
		this.digits += 1;
	}

	//表示をアップデートする
	void UpdateDisplay(){
		if(this.score > (System.Math.Pow(10,this.digits)-1) ){
			UpdateDigits();
		}

		int score = this.score;
		int _score = this.score;
		for (int i = 0; i < this.digits; i++) {
			//foreach(GameObject target in displays){
			//target.GetComponent<Distance> ().UpdateNum (score%10);
			if(best<_score){
				this.displays[i].GetComponent<Distance> ().UpdateHighNum (score % 10);// mを作る
				if(!isMetorUpdated){
					GameObject metorIns = Instantiate (metor2, transform.position, Quaternion.identity) as GameObject;
					metorIns.transform.parent = gameObject.transform;

					bestLabelIns = Instantiate(Resources.Load ("Prefabs/BestLabel")) as GameObject;
					bestLabelIns.transform.parent = gameObject.transform;
					bestLabelIns.transform.localPosition = new Vector3(-0.0225f,0,0);
					bestLabelIns.transform.localScale = new Vector3(0.004f, 0.004f, 0.004f);
					isMetorUpdated=true;
					Debug.Log(isMetorUpdated);
				}
			}else{
				this.displays[i].GetComponent<Distance> ().UpdateNum (score % 10);
			}
			score /= 10;
		}
	}
	
	// Use this for initialization
	void Start () {
		InitScore();
		UpdateDigits();
		playerTrans = GameObject.FindGameObjectWithTag ("Player").transform;
		
		// mを作る
		GameObject metorIns = Instantiate (metor, transform.position, Quaternion.identity) as GameObject;
		metorIns.transform.parent = gameObject.transform;
	}

	// Update is called once per frame
	void Update () {
		if ((int)playerTrans.position.x > maxScore) {
			maxScore = (int)playerTrans.position.x;
		}
		UpdateScore ((int)playerTrans.position.x);
		UpdateDisplay ();
	}

	public int GetMaxScore() {
		return(maxScore);
	}
}
