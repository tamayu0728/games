﻿using UnityEngine;
using System.Collections;

public class Distance : MonoBehaviour {
	SpriteRenderer MainSpriteRenderer;

	[SerializeField]
	private Sprite[] sprites = new Sprite[20];	

	//桁1つの数字
	private int num;

	public void UpdateNum(int num) {
		this.num = num % 10;
		MainSpriteRenderer.sprite = sprites [this.num];
	}

	public void UpdateHighNum(int num) {
		this.num = num % 10;
		MainSpriteRenderer.sprite = sprites [this.num+10];
	}

	void Awake(){
		MainSpriteRenderer = gameObject.GetComponent<SpriteRenderer>();
	}

	// Use this for initialization
	void Start () {
	}

	// Update is called once per frame
	void Update () {

		// MainSpriteRenderer.sprite = sprites [this.num];
	}
}
