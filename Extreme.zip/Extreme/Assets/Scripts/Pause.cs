﻿using UnityEngine;
using System.Collections;

public class Pause : MonoBehaviour {

	private bool isPause;

	// Use this for initialization
	void Start () {
		isPause = false;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void PausePushed () {
		Time.timeScale = (isPause)?1:0;
		isPause = !isPause;
	}
}
