﻿// FollowPos.cs
// 指定したオブジェクトに追従する

using UnityEngine;
using System.Collections;

public class FollowPos : MonoBehaviour {

	// 変数宣言
	private Transform playerTrans;
	
	// 開始処理 
	void Start () {
		playerTrans = GameObject.FindGameObjectWithTag("Player").transform;
	}
	
	// 更新処理 
	void Update () {
		transform.position = new Vector3(playerTrans.position.x,
										 transform.position.y,
										 transform.position.z);
	}
}
