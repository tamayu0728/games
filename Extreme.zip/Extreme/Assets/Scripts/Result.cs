﻿using UnityEngine;
using System.Collections;

public class Result : MonoBehaviour {

	private Transform playerTrans;
	private int score;
	private int digits;
	private int best;
	private GameObject[] displays = new GameObject[6];

	public	GameObject number;
	public  GameObject metor;
	public  GameObject metor2;
	public  GameObject runLabelIns;

	// Use this for initialization
	void Start () {
		playerTrans = GameObject.FindGameObjectWithTag ("Player").transform;
		score = (int)playerTrans.position.x;
		digits = score.ToString().Length;

		//スコア保持
		if (PlayerPrefs.HasKey("best")) {
        	this.best = PlayerPrefs.GetInt("best");
        	if(score>this.best){
				PlayerPrefs.SetInt("best", score);
        	}
    	}else{
        	this.best = 0;
			PlayerPrefs.SetInt("best", score);
    	}

		for(int i=0;i<digits;i++){
			this.displays [i] = Instantiate(number, transform.position + new Vector3(-0.2f + -0.55f*i, 0.1f,0), Quaternion.identity) as GameObject;
			if(best<(int)playerTrans.position.x){
				this.displays [i].GetComponent<Distance>().UpdateHighNum(0);
			}else{
				this.displays [i].GetComponent<Distance>().UpdateNum(0);
			}
			this.displays [i].transform.parent = gameObject.transform;
		}

		for (int i = 0; i < this.digits; i++) {
			//foreach(GameObject target in displays){
			//target.GetComponent<Distance> ().UpdateNum (score%10);
			if(best<(int)playerTrans.position.x){
				this.displays[i].GetComponent<Distance> ().UpdateHighNum (score % 10);
			}else{
				this.displays[i].GetComponent<Distance> ().UpdateNum (score % 10);
			}
			score /= 10;
		}


		// mを作る
		GameObject metorIns = (best<(int)playerTrans.position.x)?Instantiate (metor2, transform.position, Quaternion.identity) as GameObject:Instantiate (metor, transform.position, Quaternion.identity) as GameObject;

		metorIns.transform.parent = gameObject.transform;
		metorIns.transform.position = new Vector3(0.45f,gameObject.transform.position.y,gameObject.transform.position.z);

		runLabelIns = Instantiate(Resources.Load ("Prefabs/run")) as GameObject;
		runLabelIns.transform.parent = gameObject.transform;
		runLabelIns.transform.localPosition = new Vector3(0, -200.0f , -100.0f);
		runLabelIns.transform.localScale = new Vector3(150.0f, 150.0f, 150.0f);

		Debug.Log(best);

	}
	
	// Update is called once per frame
	void Update () {
	
	}

	/*
	 * restart
	 */
	public void RestartPushed () {
		GameObject.FindGameObjectWithTag("GameController").SendMessage("Restart");
	}

	/*
	 * top
	 * 未実装
	 */
	public void TopPushed () {
		GameObject.FindGameObjectWithTag("GameController").SendMessage("ToTitle");	
	}
}
