﻿using UnityEngine;
using System.Collections;
using System;





[RequireComponent( typeof(AudioSource))]
public class AudioFade : MonoBehaviour
{
	public float AudioFadeSpeed;
	public float maxAudioVolume;
	
	int volume = 0;
	
	#region Unity_delegate
	void OnEnable ()
	{
		StopAllCoroutines();
		if(gameObject.activeSelf){
			StartCoroutine("Fadein");
		}
	}
	
	void OnDisable ()
	{
		StopAllCoroutines();
		if(gameObject.activeSelf ){
			StartCoroutine("Fadeout");
		}
	}
	#endregion
	
	IEnumerator Fadein ()
	{
		GetComponent<AudioSource>().enabled = true;
		for (; volume<maxAudioVolume; volume++) {
			GetComponent<AudioSource>().volume = (float)volume / AudioFadeSpeed;
			yield return null;
		}
		GetComponent<AudioSource>().volume = maxAudioVolume/AudioFadeSpeed;

		// modified : Lost BGM Bug
		if(!GetComponent<AudioSource>().isPlaying){
			GetComponent<AudioSource>().volume = 0f;
			GetComponent<AudioSource>().Play();
			StartCoroutine("Fadein");
		}
	}
	
	IEnumerator Fadeout ()
	{
		for (; volume>0; volume--) {
			GetComponent<AudioSource>().volume =  (float)(volume) / AudioFadeSpeed;
			yield return null;
		}
		GetComponent<AudioSource>().volume = 0;
		GetComponent<AudioSource>().enabled = false;

		Destroy(gameObject);
		Resources.UnloadAsset(GetComponent<AudioSource>().clip);
	}
}
