﻿using UnityEngine;
using System.Collections;

public class GameController : SingletonMonoBehaviour<GameController> {

	// const
	private const float DEFAULT_PLAYER_POS_Y = -0.75f;
	private const float PAUSE_X = -850.0f;
	private const float PAUSE_Y = 1470.0f;	

	// Game Statement
	public enum GameState {
		TITLE,
		PLAYING,
		RESULT,
	}
	public GameState state;
	
	// 変数宣言
	public int frameRate;

	// 動的オブジェクト
	private GameObject score;
	private GameObject pause;
	private GameObject title;
	private GameObject result;
	private GameObject player;
	private GameObject bestFlg;

	// Frame rate
	void Awake() {
		Application.targetFrameRate = frameRate;
		
		// Player instantiate
		player = Instantiate(Resources.Load("Prefabs/Player")) as GameObject;


		// Title instantiate
		title = Instantiate(Resources.Load("Prefabs/TitleSprite")) as GameObject;
		// title.transform.parent = GameObject.Find ("Camera").transform;

		// Default title
		state = GameState.TITLE;
		
		// BEST旗を生成
		if(bestFlg)
			Destroy(bestFlg.gameObject);
		if(PlayerPrefs.HasKey("best")) {
			bestFlg = Instantiate(Resources.Load("Prefabs/BestFlg")) as GameObject;
			float best = 0.0f;		
			best = (float)PlayerPrefs.GetInt("best");
			bestFlg.transform.position = new Vector3(best, -6.0f, 0);
		}		

	}

	// Use this for initialization
	void Start () {

		AudioManager.Instance.FadeGameBGM ();
		// Debug

	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown (0) && state == GameState.TITLE) {
			ToPlaying();
		}
		
	}
	
	// To Playing
	void ToPlaying() {
		// ポーズボタンを生成
		/*
		if(pause)
			Destroy(pause.gameObject);
		pause = Instantiate(Resources.Load ("Prefabs/PauseButton")) as GameObject;
		pause.transform.parent = GameObject.Find ("Camera").transform;
		pause.transform.localPosition = new Vector3(PAUSE_X, PAUSE_Y , 0);
		pause.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
		*/
		
		// Score instantiate
		score = Instantiate(Resources.Load("Prefabs/Score")) as GameObject;
		score.transform.parent = GameObject.Find ("Camera").transform;	
		
		//タイトル削除
		Destroy (title);

		state = GameState.PLAYING;
	}
	
	// To Result
	void ToResult() {		
		if(result != null)
			Destroy(result);
		
		// プレイヤーを動かないようにする
		Destroy(player.GetComponent<Rigidbody2D>());
		
		// ズーム終了
		GameObject.FindGameObjectWithTag("MainCamera").SendMessage("ZoomEnd");
		GameObject.FindGameObjectWithTag("BackCamera").SendMessage("ZoomEnd");		
		
		// スコア削除
		Destroy (score);
		
		// リザルトを生成
		state = GameState.RESULT;
		result = Instantiate(Resources.Load ("Prefabs/Result")) as GameObject;
		result.transform.parent = GameObject.Find ("Camera").transform;
		result.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
		
		// ポーズボタンを削除
		if(pause)
			Destroy (pause.gameObject);
	}
	
	// Restart
	void Restart() {
		if(result != null)
			Destroy(result);
		
		// プレイヤーを再設定	
		player.AddComponent<Player>();
		player.AddComponent<Rigidbody2D>();
		player.transform.position = new Vector3(0, DEFAULT_PLAYER_POS_Y, 0);
		player.transform.FindChild("Sprite").transform.localRotation = Quaternion.identity;
		
		// スコア再生成
		score = Instantiate(Resources.Load("Prefabs/Score")) as GameObject;
		score.transform.parent = GameObject.Find ("Camera").transform;		
		
		// ジャンプ判定初期化
		GameObject.Find ("JumpZone").GetComponent<BoxCollider2D>().size = new Vector2(10.0f, 1.2f);
		GameObject.Find ("JumpZone").GetComponent<BoxCollider2D>().offset = new Vector2(0, 0);
		
		// ポーズボタンを生成
		/*
		pause = Instantiate(Resources.Load ("Prefabs/PauseButton")) as GameObject;
		pause.transform.parent = GameObject.Find ("Camera").transform;
		pause.transform.localPosition = new Vector3(PAUSE_X, PAUSE_Y , 0);
		pause.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
		*/
		
		// BEST旗を生成
		if(bestFlg)
			Destroy(bestFlg.gameObject);
		if(PlayerPrefs.HasKey("best")) {
			bestFlg = Instantiate(Resources.Load("Prefabs/BestFlg")) as GameObject;
			float best = 0.0f;		
			best = (float)PlayerPrefs.GetInt("best");
			bestFlg.transform.position = new Vector3(best, -6.0f, 0);
		}
		
		// カメラ初期化
		GameObject.FindGameObjectWithTag("MainCamera").SendMessage("Init");
		GameObject.FindGameObjectWithTag("BackCamera").SendMessage("Init");			
		
		state = GameState.PLAYING;
	}
	
	// To Title
	void ToTitle() {
		if(result != null)
			Destroy(result);
		
		// プレイヤーを再設定	
		player.AddComponent<Player>();
		player.AddComponent<Rigidbody2D>();
		player.transform.position = new Vector3(0, DEFAULT_PLAYER_POS_Y, 0);
		player.transform.FindChild("Sprite").transform.localRotation = Quaternion.identity;	
		
		// ジャンプ判定初期化
		GameObject.Find ("JumpZone").GetComponent<BoxCollider2D>().size = new Vector2(10.0f, 1.2f);
		GameObject.Find ("JumpZone").GetComponent<BoxCollider2D>().offset = new Vector2(0, 0);
		
		// ポーズボタンを生成
		/*
		pause = Instantiate(Resources.Load ("Prefabs/PauseButton")) as GameObject;
		pause.transform.parent = GameObject.Find ("Camera").transform;
		pause.transform.localPosition = new Vector3(PAUSE_X, PAUSE_Y , 0);
		pause.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
		*/
		
		// カメラ初期化
		GameObject.FindGameObjectWithTag("MainCamera").SendMessage("Init");
		GameObject.FindGameObjectWithTag("BackCamera").SendMessage("Init");	
		
		// BEST旗を生成
		if(bestFlg)
			Destroy(bestFlg.gameObject);
		if(PlayerPrefs.HasKey("best")) {
			bestFlg = Instantiate(Resources.Load("Prefabs/BestFlg")) as GameObject;
			float best = 0.0f;		
			best = (float)PlayerPrefs.GetInt("best");
			bestFlg.transform.position = new Vector3(best, -6.0f, 0);
		}
		
		// Title instantiate
		title = Instantiate(Resources.Load("Prefabs/TitleSprite")) as GameObject;
		
		state = GameState.TITLE;

		PlayerPrefs.DeleteAll();
	}	
}
