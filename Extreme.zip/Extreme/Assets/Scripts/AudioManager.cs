﻿using UnityEngine;
using System.Collections;

public class AudioManager : SingletonMonoBehaviour<AudioManager> {
	public bool EnableSE, EnableBGM, EnableHardBGM;

	[SerializeField]
	private AudioSource m_Broken, m_JumpGreat, m_JumpBad, m_Button;

	[SerializeField]
	//private GameObject m_Opening, m_NormalBGM, m_HardBGM;
	private string m_OpeningBGMPath, m_GameBGMPath;

	private AudioSource m_CurrentSE = null;
	private void PlaySE(AudioSource source){
		if(EnableSE){
			source.Play();
			m_CurrentSE = source;
		}
	}
	public void ResetSE(){
		if(EnableSE){
			if(m_CurrentSE != null){
				m_CurrentSE.mute = false;
			}
		}
	}
	public void PlayBroken(){
		PlaySE(m_Broken);
	}

	public void PlayJumpGreat(){
		PlaySE(m_JumpGreat);
	}

	public void PlayJumpBad(){
		PlaySE(m_JumpBad);
	}

	public void PlayButton(){
		PlaySE(m_Button);
	}

	private AudioFade m_CurrentFade = null;

	private void FadeBGM(string path){
		GameObject loadBGM = Resources.Load<GameObject>(path);
		loadBGM = Instantiate(loadBGM) as GameObject;
		StopBGM();
		m_CurrentFade = loadBGM.GetComponent<AudioFade>();
		if(EnableBGM){
			m_CurrentFade.enabled = true;
			m_CurrentFade.GetComponent<AudioSource>().Play();
		}
	}
	public void StopBGM(){
		if(m_CurrentFade != null){
			m_CurrentFade.enabled = false;
		}
		m_CurrentFade = null;
	}

	public void FadeOpening(){
		FadeBGM(m_OpeningBGMPath);

	}
	public void FadeGameBGM(){
		FadeBGM(m_GameBGMPath);
	}
	
}
