﻿using UnityEngine;
using System.Collections;

public class WaveController : MonoBehaviour {

	// 定数宣言
	private const int MAX_WAVE = 30;
	private const float ADD_POS = 1.0f;

	// Use this for initialization
	void Start () {
		// 波表示
		for(int i = 0; i < MAX_WAVE; i ++) {
			GameObject wave = Instantiate (Resources.Load("Prefabs/Water"), transform.position, Quaternion.identity) as GameObject;
			wave.transform.position += new Vector3(i * 15.0f, 2.0f + (i % 2) * 2.0f - Random.Range (-1.0f, 1.0f), 0);
			wave.transform.parent = transform;
		}
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
