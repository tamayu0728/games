﻿// Player.cs
// プレイヤーアクションを制御する

using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	// 定数宣言
	private const float DEFAULT_POWER = 4.0f;
	private const float ADD_POWER = 0.8f;
	private const float ROT_SPEED = 180.0f;
	private const float ADD_GRAVIDY = 0.1f;
	private const float ADD_ZONE_SIZE = 0.15f;
	private const float ADD_ZONE_CENTER = -0.12f;
	private const float ADD_SLOW = 300f;
	private const float ANGLE_SIZE = 0.03f;
	private const float DEFAULT_ANGLE = 1f;
	private const float GOOD_RAITO = 0.4f;
	private const float MAX_DOWN_SPEED = -8f;
	private const float TOP_HIGH = 20f;
	private const float PLAYER_DIFF = 0.3f;
	private float m_visibleMountainHight = 0f;
	private float m_visibleMountainHight2 = 5f;

	//デバッグモード
	private const bool dbg = false;

	// 変数宣言
	private bool touchEnable;
	private bool noTouch;
	private Vector2 power;
	private Vector2 slow;
	private Vector2 angle;
	private Rigidbody2D rigid;
	private bool maxTop = false;
	private float maxTopSpeed = 0f;
	private float timing = 0f;
	private GameObject particle;
	private GameObject judge;
	private GameObject combo;
	private GameObject trail;
	private bool firstTouch;
	private bool SpeedLimit = false;
	private int Combo = 0;
	private Animator waveAnim;
	private GameObject[] MountainSprite;
	private GameObject[] MountainSprite2;
	private bool topDance = false;

	// 開始処理 
	void Start () {
		touchEnable = true;
		noTouch = false;
		firstTouch = false;
		power.x = DEFAULT_POWER;
		power.y = DEFAULT_POWER;
		slow.x = 0;
		slow.y = ADD_SLOW;
		angle.x = DEFAULT_ANGLE;
		angle.y = DEFAULT_ANGLE;
		rigid = transform.GetComponent<Rigidbody2D>();
		GetComponent<BoxCollider2D>().offset = new Vector2(0, -0.8f);
		
		// Animation
		Animator anim = GameObject.Find ("Human_center").GetComponent<Animator>();	
		anim.Play ("PlayerAnimationDance");
		waveAnim = GameObject.Find ("WaveSea").GetComponent<Animator> ();
		
		// Trail
		trail = Instantiate(Resources.Load("Prefabs/Trail")) as GameObject;
		trail.transform.position += transform.position;
		trail.transform.parent = transform;	

		MountainSprite = GameObject.Find ("MountainScroller").GetComponent<roadScrollerScript>().Roads;
		MountainSprite2 = GameObject.Find ("MountainScroller2").GetComponent<roadScrollerScript>().Roads;


	}
	
	// 更新処理 
	void Update () {

		if(this.transform.position.y > m_visibleMountainHight){
			foreach (var mountain in MountainSprite) {
				var color = mountain.GetComponent<SpriteRenderer>().color;
				if(color.a <= 1){
					color.a = this.transform.position.y / ( m_visibleMountainHight + 10f);
					Debug.Log ("alpha" + color.a);
					mountain.GetComponent<SpriteRenderer>().color = color;
				}else if(color.a > 1.0){
					color.a = 1.0f;
					mountain.GetComponent<SpriteRenderer>().color = color;
					
				}
			}
		}

		if(this.transform.position.y > m_visibleMountainHight2){
			foreach (var mountain in MountainSprite2) {
				var color = mountain.GetComponent<SpriteRenderer>().color;
				if(color.a <= 1){
					color.a = this.transform.position.y / ( m_visibleMountainHight2 + 10f);
					//Debug.Log ("alpha" + color.a);
					mountain.GetComponent<SpriteRenderer>().color = color;
				}else if(color.a > 1.0){
					color.a = 1.0f;
					mountain.GetComponent<SpriteRenderer>().color = color;
					
				}
			}
		}
		
		

		// Animation
		Animator anim = GameObject.Find ("Human_center").GetComponent<Animator>();	

		SlowSpeed ();

		if (dbg) {
			if (touchEnable == true) {
				IcanFly ();
			}
		}

		// タッチされたら、主人公を前方へ飛ばす
		if(Input.GetMouseButtonDown(0) && noTouch == false) {
			
			// 初回
			if(firstTouch == false) {
				anim.Play ("JumpAnimation");
				CancelInvoke();
				Invoke("RotAnimPlay", 0.8f);
				firstTouch = true;
				IcanFly ();
				GetComponent<BoxCollider2D>().offset = new Vector2(0, -PLAYER_DIFF);
				return;
			}	
			
			// ジャンプ有効範囲内なら飛ぶ
			if(touchEnable == true) {
				IcanFly ();

				SpeedLimit = false;

				if(particle) {
					Destroy(particle.gameObject);
				}
	
				if(CheckTiming() == 1) {
					AudioManager.Instance.PlayJumpGreat();
					waveAnim.Play("Wave");

					particle = Instantiate(Resources.Load ("Prefabs/Good"), new Vector3(-0.4f, transform.position.y - 0.3f, -1.0f), Quaternion.identity) as GameObject;
				
					CancelInvoke();
					DestroyJudge();
					judge = Instantiate(Resources.Load ("Prefabs/GreatStr")) as GameObject;				
					combo = Instantiate(Resources.Load("Prefabs/Combo")) as GameObject;
					Invoke("DestroyJudge", 1.0f);
					
					anim.Play ("RotationOnly");
					
					trail.GetComponent<TrailRenderer>().material = Resources.Load("Materials/Great") as Material;
					
				} else if(CheckTiming() == 0) {
					AudioManager.Instance.PlayJumpBad();
					waveAnim.Play("Wave");

					particle = Instantiate(Resources.Load ("Prefabs/Bad"), new Vector3(-0.4f, transform.position.y - 0.3f, -1.0f), Quaternion.identity) as GameObject;	
					
					CancelInvoke();	
					DestroyJudge();
					judge = Instantiate(Resources.Load ("Prefabs/GoodStr")) as GameObject;
					Invoke("DestroyJudge", 1.0f);
					
					anim.Play ("RotationOnly");
					
					trail.GetComponent<TrailRenderer>().material = Resources.Load("Materials/Good") as Material;
				}
				
			}
			// 範囲外であればそのまま落下
			else {
				noTouch = true;
				CancelInvoke();		
				anim.Play ("playerRotation");
				waveAnim.Play("Wave");
				
				DestroyJudge();
				judge = Instantiate(Resources.Load ("Prefabs/BadStr")) as GameObject;
				
				if(trail)
					Destroy(trail.gameObject);	
			}

		}
		
		if(noTouch == true) {
			transform.FindChild("Sprite").Rotate(new Vector3(0, 0, -ROT_SPEED * Time.deltaTime));
		}
	}
	
	void RotAnimPlay() {
		Animator anim = GameObject.Find ("Human_center").GetComponent<Animator>();
		anim.Play ("RotationOnly");	
	}
	
	void DestroyJudge() {
		if(judge) {
			Destroy(judge.gameObject);
		}
		if(combo) {
			Destroy(combo.gameObject);
		}
	}
	
	// 判定領域と接触開始
	void OnTriggerEnter2D(Collider2D other) {
		// ジャンプ領域と触れたら、タッチを有効にする
		if(other.name == "JumpZone") {
			touchEnable = true;
		}
		
		// ゲームオーバー領域と触れたら、リザルト表示
		if(other.name == "FailZone") {

			AudioManager.Instance.PlayBroken();

			if(trail)
				Destroy(trail.gameObject);
			if(particle)
				Destroy(particle.gameObject);
			DestroyJudge();
			GameObject.FindGameObjectWithTag("GameController").SendMessage("ToResult");
			Destroy (this);
		}
	}
	
	// 判定領域と接触終了
	void OnTriggerExit2D(Collider2D other) {
		// ジャンプ領域から離れたら、タッチを無効にする
		if(other.name == "JumpZone") {
			touchEnable = false;
		}
	}

	//タイミング判定
	public int CheckTiming(){
		if (dbg) {
			return(1);
		}

		GameObject jumpZone = GameObject.Find("JumpZone");
		timing = ((transform.position.y - PLAYER_DIFF) -  jumpZone.transform.position.y) / (jumpZone.GetComponent<BoxCollider2D>().size.y / 2.0f);

		if (System.Math.Abs (timing) < GOOD_RAITO) {
			return(1);
		} else {
			return(0);
		}
	}

	//コンボ取得
	public int GetCombo(){
		return(Combo);
	}

	//ジャンプ加速
	void JumpUp(){
		//高さ制限でなら上方向一定
		if (maxTop) {
			power.y = maxTopSpeed;
		} else {
			power.y += ADD_POWER * Combo * 0.8f;
		}

		//10コンボ超えると超加速
		if (Combo > 10) {
			power.x += ADD_POWER * Combo * Combo;
		} else {
			power.x += ADD_POWER * Combo * 3f;
		}

		//rigid.gravityScale += ADD_GRAVIDY;
	}

	//速度リセット
	void JumpReset(){
		power.x = DEFAULT_POWER + power.x/24;
		power.y = DEFAULT_POWER + power.y/4;
		rigid.gravityScale += ADD_GRAVIDY;
		maxTop = false;
		topDance = false;
		StartRotAnim ();
	}

	//ジャンプ処理
	void IcanFly(){
		CancelSpeedLimit ();

		if ( CheckTiming() == 1) {
			Combo += 1;
			JumpUp();
		} else {
			Combo = 0;
			JumpReset ();
			//GameObject.Find ("JumpZone").GetComponent<BoxCollider2D>().size += new Vector2(0, ADD_ZONE_SIZE);
		}

		rigid.velocity = Vector2.zero;
		rigid.AddForce(power, ForceMode2D.Impulse);
		touchEnable = false;

		// ズーム開始
		GameObject.FindGameObjectWithTag("MainCamera").SendMessage("ZoomStart");
		GameObject.FindGameObjectWithTag("BackCamera").SendMessage("ZoomStart");		
		
		//GameObject.Find ("JumpZone").GetComponent<BoxCollider2D>().center += new Vector2(0, ADD_ZONE_CENTER);
	}

	//踊り開始
	void StartDanceAnim(){
		Animator anim = GameObject.Find ("Human_center").GetComponent<Animator>();
		anim.Play ("PlayerAnimationDance");
	}

	//回転開始
	void StartRotAnim(){
		Animator anim = GameObject.Find ("Human_center").GetComponent<Animator>();
		anim.Play ("RotationOnly");
	}

	//上空でのふわっと感を出す
	void SlowSpeed(){
		slow.y = ADD_SLOW;

		//最大の高さを更新する
		if (rigid.transform.position.y > TOP_HIGH) {
			maxTop = true;
			maxTopSpeed = power.y;
		}

		//最高速度に到達したら判定レベルを一定にする
		if (SpeedLimit == true) {
			if(rigid.transform.position.y < -2){
				rigid.velocity = new Vector2 (rigid.velocity.x, MAX_DOWN_SPEED);
			}
		} else if (rigid.velocity.y < MAX_DOWN_SPEED) {
			SpeedLimit = true;
		}


		if (rigid.transform.position.y > (TOP_HIGH - Combo) || !firstTouch) {
			//anim.Play ("PlayerAnimationDance");
			StartDanceAnim ();
			topDance = true;
		} else {
			if(topDance){
				StartRotAnim ();
			}
		}
	}

	//スピードリミットの解除
	void CancelSpeedLimit(){
		SpeedLimit = false;
		rigid.gravityScale = 1;
	}

	/*
	void OnGUI(){
		GUI.Label (new Rect(5,10,100,90), rigid.velocity.y.ToString());
		GUI.Label (new Rect(5,30,200,200), rigid.transform.position.y.ToString());
		GUI.Label (new Rect(5,50,200,200), angle.ToString());
		GUI.Label (new Rect(5,70,200,100), timing.ToString());
		GUI.Label (new Rect (5, 90, 200, 100), GameObject.Find ("JumpZone").GetComponent<BoxCollider2D> ().size.y.ToString());
		if(CheckTiming() == 0)
			GUI.Label (new Rect(5, 110, 200, 100), "Bad!");
		else if(CheckTiming() == 1) 
			GUI.Label (new Rect(5, 110, 200, 100), "Good!");

		GUI.Label (new Rect(5, 130, 200, 100), Combo.ToString());
	}
	*/
}
