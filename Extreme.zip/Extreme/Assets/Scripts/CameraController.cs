﻿// CameraController.cs
// カメラの動きを制御する

using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

	// 定数宣言
	private const float DEFAULT_ZOOM = 5.0f;
	private const float ADD_BASEPOINT = 1.0f;
	private const float DEFAULT_BASE = 1.5f;

	// 変数宣言
	public bool fixedX = false;
	public float zoomSize;
	public float moveRatio;
	private bool zoomStart;
	private float basePoint;
	private float baseZoom;
	private Transform playerTrans;

	private float m_screenHight;

	public float ScreenHight{
		get{ return m_screenHight;}	
	}

	// 開始処理 
	void Start () {
		Init ();
		playerTrans = GameObject.FindGameObjectWithTag("Player").transform;
	}
	
	// 初期化
	void Init() {
		basePoint = DEFAULT_BASE;
		baseZoom = DEFAULT_ZOOM;
		zoomStart = false;
	}
	
	// 更新処理 
	void Update () {

		m_screenHight = this.GetComponent<Camera>().ScreenToWorldPoint (new Vector3 (0, Screen.height, 0)).y - this.transform.position.y;
				                                           
//		m_screenHight = this.camera.ScreenToWorldPoint (new Vector3 (0, 0, 0));		                                           


		float height = playerTrans.position.y - basePoint;
		if(height < 0)
			height = 0;
		
		transform.GetComponent<Camera>().orthographicSize = baseZoom + height * zoomSize;
		transform.position = new Vector3(0, height * zoomSize / moveRatio, -10.0f);

		if(zoomStart == true) {						
			//basePoint -= ADD_BASEPOINT * Time.deltaTime;
		}
		
		if(fixedX == false) {
			transform.position = new Vector3(playerTrans.position.x,
			                                 transform.position.y,
			                                 transform.position.z);
		}                      
	}
	
	// ズーム開始
	void ZoomStart() {
		zoomStart = true;
	}
	
	// ズーム終了
	void ZoomEnd() {
		zoomStart = false;
	}
}
